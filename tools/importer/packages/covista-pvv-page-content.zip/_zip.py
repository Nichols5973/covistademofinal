import zipfile, os
out = "/workspace/current/tools/importer/packages/covista-pvv-page-content.zip"
base = "/workspace/current/migration-work/pvv-page-package"
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(base):
        for f in files:
            full = os.path.join(root, f)
            z.write(full, os.path.relpath(full, base))
